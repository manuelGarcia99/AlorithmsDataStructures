
PNodoAB criarABAleatoria (int);

void numNodoFilhos(PNodoAB T,int *nEsq, int *nDir);

int quantosIguais(PNodoAB T , int k );


#include"ABExerciciosA.c"