
PNodo criarListaAleatoria(int);


#include "ListasExerciciosA.c"


