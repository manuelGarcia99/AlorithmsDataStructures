
#include <stdio.h>
#include <stdlib.h>

#include "Aleatorio.h"
#include "OperacoesPrimariasA.h"
#include "ListasLigadasSimples.h"
#include "ListasExerciciosA.h"


int main(){
  PNodo Lista;
  int TAM, Num, quantP;
  float somaPag, Pag, maior;
  
  // A1.1
  TAM = gerarNumeroInteiro(0, 15);
  printf("TAM = %d\n", TAM);
  Lista = criarListaAleatoria(TAM);
  
  // A.2
  printf("listar inicio para fim:\n");
  mostrarListaInicio(Lista);
  printf("listar fim para inicio:\n");
  mostrarListaFimRec(Lista);

  // A.3
  printf("Insira um NIF:");
  scanf("%d", &Num);
  somaPag = somaPagamentos(Lista, Num);
  printf("soma pagamentos = %f\n", somaPag);

  // A.4
  /*
  se der 400 de input, devolve a soma dos pagamentos de mais
de 400 euros
*/
  printf("Insira um valor de Pagamentos: ");
  scanf("%f", &Pag);
  quantP = quantPagamentos(Lista, Pag);
  printf("Quant pagamentos=%d\n", quantP);

  // A.5
  maior = maiorPagamentoRec(Lista);
  printf("%f\n", maior);

  
}
